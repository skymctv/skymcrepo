# -*- coding: utf-8 -*-
import re,os,base64,xbmcgui,HTMLParser
import xbmc,urllib,urllib2
import xbmcaddon
import xbmcplugin,sys
from BeautifulSoup import BeautifulSoup
addon_id = 'plugin.video.tivibu'
Addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(id=addon_id)
home = __settings__.getAddonInfo('path')
library = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
sys.path.append(library)
images_path = xbmc.translatePath(os.path.join(home, 'resources','images'))
sys.path.append(images_path)
fanart = xbmc.translatePath( os.path.join( home, 'icon.png' ) )
Fanart = 'special://home/addons/'+addon_id+'/resources/images/Fanart.jpg'
addon_icon    = __settings__.getAddonInfo('icon')
FILENAME = "TIVIBU"
# https://github.com/skymctv/skymcxml/blob/master/tivi.xml
web_url='https://raw.githubusercontent.com/skymctv/skymcxml/master/tivi.xml'
web_xml='E:/xttmc/xttmc/skymctv/skymcxml/tivi.xml'
xbmcPlayer = xbmc.Player()
xbmcPlayer.stop()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
playList.clear()
# eklentiler = xbmc.translatePath(os.path.join(home, 'channels'))
# sys.path.append(eklentiler)
# xttalternatif = xbmc.translatePath(os.path.join(home, 'channels','xttalternatif'))
# sys.path.append(xttalternatif)
# xttsinemapaket = xbmc.translatePath(os.path.join(home, 'channels','xttsinemapaket'))
# sys.path.append(xttsinemapaket)
# channels = xbmc.translatePath(os.path.join(home, 'channels','xttsinemapaket2'))
# sys.path.append(channels)
# channels = xbmc.translatePath(os.path.join(home, 'channels','xttsinemapaket3'))
# sys.path.append(channels)
# xttdizimax = xbmc.translatePath(os.path.join(home, 'channels','xttdizimax'))
# sys.path.append(xttdizimax)
# xtttest = xbmc.translatePath(os.path.join(home, 'xtttest'))
# sys.path.append(xtttest)
# xtttest = xbmc.translatePath(os.path.join(home, 'channels','xtttest'))
# sys.path.append(xtttest)
# import XTTkoditools
def main():
    BuildPagehtml()
    # BuildPagexml()
'''################################'''

#################################  orj  #########################################
def BuildPagehtml():
    html=get_url(web_url)
    if '.' in html:
        soup = BeautifulSoup(html)
    else:
        soup = BeautifulSoup(HTMLParser.HTMLParser().unescape(base64.b64decode(html)))
    item = soup.findAll("item")
    for i in range(len(item)):
        name = item[i].title.string
        streamlink = item[i].streamlink.string
        thumbnail = item[i].thumbnail.string
        xttplay(FILENAME, '[B]'+str(int(i)+1)+'[COLOR red]) [COLOR darkgray]'+name.encode('iso-8859-9', 'ignore')+'[/COLOR][/B]', "", streamlink, thumbnail, "", "")
    xbmc.executebuiltin("Container.SetViewMode(500)")
    
#################################  xml  #########################################
def BuildPagexml():
    gf = open(web_xml, 'r')
    html = gf.read()
    if '.' in html:
        soup = BeautifulSoup(html)
    else:
        soup = BeautifulSoup(HTMLParser.HTMLParser().unescape(base64.b64decode(html)))
    item = soup.findAll("item")
    for i in range(len(item)):
        name = item[i].title.string
        streamlink = item[i].streamlink.string
        thumbnail = item[i].thumbnail.string
        xttplay(FILENAME, '[B]'+str(int(i)+1)+'[COLOR red]) [COLOR darkgray]'+name.encode('iso-8859-9', 'ignore')+'[/COLOR][/B]', "", streamlink, thumbnail, "", "")
    xbmc.executebuiltin("Container.SetViewMode(500)")
    
################################################################################
USER_AGENT='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'
def get_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
def get_url_headers(url,headers={}):
    req = urllib2.Request(url,headers=headers)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
def xtturl_headers(url):
    # headers={'Referer': url,'User-Agent': USER_AGENT}
    # req = urllib2.Request(url,headers=headers)
    req = urllib2.Request(url,headers={'Referer': url,'User-Agent': USER_AGENT})
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
def xttplay(FILENAME,name,method,url,thumbnail,thumbfolder,fix):#addDirxbmctrtools
    if thumbfolder != "":
        thumbfolder = os.path.join(images_path, thumbfolder+".png")
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&method="+str(method)+"&name="+urllib.quote_plus(name)+"&thumbnail="+urllib.quote_plus(thumbnail)+"&thumbfolder="+urllib.quote_plus(thumbfolder)+"&fileName="+urllib.quote_plus(FILENAME)+"&fix="+urllib.quote_plus(fix)
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumbnail or thumbfolder)
    liz.setInfo(type="Video", infoLabels={"Title": name })
    # liz.setProperty('fanart_image', thumbnail or thumbfolder)
    liz.setProperty('fanart_image', Fanart) or ("IsPlayable", "true")
    if method != "":
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        # ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        # return ok
    else:
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
#####################################
def showMessage(str, header='', time=2000):
    try: xbmcgui.Dialog().notification(header, str, addon_icon, time, sound=False)
    except: xbmc.executebuiltin("Notification(%s,%s, %s, %s)" % (header, str, time, addon_icon))
def replace_fix(x):
    x=x.replace(';=', '=')
    return x
################################################################################

    # if (__name__ == '__main__' ):
        # import XTTMCEXTRA
        # XTTMCEXTRA.main()
##-----direk çalıştırma seçenekleri-----##3 seçenekten hangisini kullanırsan ayrıca altta "XTTkoditools.listing(images_path,xtttest)" seçeneğini kapat
    # if (__name__ == '__main__' ):
        # import xttmctv
        # xttmctv.main()
        
    # for nameimp in os.listdir(xtttest):
        # namepy=re.compile('(.*?).py').findall(str(nameimp))
        # for nameimport in namepy:
            # if '__' in nameimport:
                # pass
            # else:
                # exec "import "+nameimport+" as test_et"
                # return test_et.main()
                
    # print os.listdir(xtttest)
    # ['denemeler', 'sayfalama.py', 'sayfalama.pyo', 'XTT1SITE.py', 'XTT1SITE.zip', '__init__.py']
    # nameimport=re.search('\'([^\'\"]+).py+\'+', str(os.listdir(xtttest))).group(1)
    # print nameimport
    # exec "import "+nameimport+" as test_et"
    # return test_et.main()
##-----direk çalıştırma seçenekleri bitti-----## 
  
    # xttplay("xtttv", "[B][COLOR darkgray]XTT[/COLOR][COLOR red]TV[/COLOR][/B]", "main()", "","", "xtttv","")
    # xttplay("xttmctv", "[B][COLOR lightblue]XTT[COLOR red]TV[/COLOR]KATEGORI[/B]", "main()", "","", "xtttv","")
    # xttplay("xttmctv", "[B][COLOR lightblue]XTT[COLOR red]TV[/COLOR][/B]", "main()", "","", "xtttv","")
    # xttplay("tvalternatif", "[B][COLOR lightblue]ALTERNATIF[/COLOR][COLOR red]TV[/COLOR][/B]", "main()", "","", "xttmobitv","")
    # xttplay("sinepaket", "[B][COLOR lightblue]SINE[/COLOR][COLOR blue]MAX[/COLOR][/B]", "main()", "","", "fullfilm","")
    # xttplay("xttmcturkfilm", "[B][COLOR lightblue]TURK[COLOR red]MAX[/COLOR][/B]", "main()", "","", "xttturk","")
    # xttplay("dizipaket", "[B][COLOR lightblue]DIZI[/COLOR][COLOR fuchsia]MAX[/COLOR][/B]", "main()", "","", "xttdizi","")
    # xttplay("dizimax", "[B][COLOR lightblue]DIZI[/COLOR][COLOR fuchsia]MAX[/COLOR][/B]", "main()", "","", "xttdizi","")
    # xttplay("xttsmarttv", "[B][COLOR lightblue]XTT[COLOR red]SMART[/COLOR]TV[/B]", "main()", "","", "xttsmarttv","")
    # xttplay("xttlivetv", "[B][COLOR lightblue]XTT[COLOR red]SMART[/COLOR]LIVE[/B]", "main()", "","", "xttsmarttv","")
    # xttplay("TIVIBU", "[B][COLOR darkgray]TIVI[/COLOR][COLOR red]BU[/COLOR][/B]", "main()", "","", "xtttv","")
    # xttplay("canlitvlive", "[B][COLOR lightblue]LIVE[COLOR red]TV[/COLOR][/B]", "main()", "","", "canlitvlive","")
    # xttplay("canlitvlivesite", "[B][COLOR lightblue]ALTERNATIF[/COLOR][COLOR red]TV[/COLOR][/B]", "main()", "","", "xttmobitv","")
    # xttplay("xttsmarttv", "[B][COLOR lightblue]XTT[COLOR red]SMART[/COLOR]TV[/B]", "main()", "","", "xttsmarttv","")
    # xttplay("xttwebtv", "[B][COLOR lightblue]XTTWEB [COLOR red]TV[/COLOR][/B]", "main()", "","", "xttwebtv","")
    # xttplay("sinepaket", "[B][COLOR blue]SINEPAKET [COLOR dimgray]1[/COLOR][/B]", "main()", "","", "sinema1","")
    # xttplay("sinepaket2", "[B]SINE[COLOR blue]MAX[COLOR dimgray]2[/COLOR][/B]", "main()", "","", "sinema2","")
    # xttplay("sinemax", "[B]SINE[COLOR blue]MAX[COLOR dimgray]2[/COLOR][/B]", "main()", "","", "sinema2","")
    # xttplay("dizimax2", "[B][COLOR lightblue]DIZI[/COLOR][COLOR fuchsia]MAX[COLOR lightblue]2[/COLOR][/B]", "main()", "","", "xttdizi","")
    # xttplay("moviexk", "[B][COLOR lightblue]MOVIE[COLOR red]X[/COLOR][/B]", "main()", "","", "moviexkto","")
    # xttplay("xtthayvanlar", "[COLOR green][B]ANIMAL[/B][/COLOR]", "main()", "","", "hayvanlar","")
    # xttplay("xttmctv2", "[COLOR blue][B]TV [COLOR yellow]STANDART[/B][/COLOR]", "main()", "","", "xtttv","")
    # xttplay("xttmctstv", "[COLOR yellow][B]TS [COLOR red]TV[/B][/COLOR]", "main()", "","", "xtttstv")
    # xttplay("sinepaket3", "[COLOR blue][B]SINEPAKET [COLOR green] 3[/B][/COLOR]", "main()", "","", "sinema3","")
    # xttplay("xttmc24", "[COLOR yellow][B]>> [COLOR red]+24 [COLOR yellow]<< [COLOR blue][B]FILM[/B][/COLOR]", "main()", "","", "xttmc24","")
    # klasorler=os.walk(xtttest).next()[1]
    # for klasor in klasorler:
        # fileName=klasor.replace(" ","")
        # name='[COLOR lightblue][B]'+klasor+'[/B][/COLOR]'
        # thumbnail= os.path.join(IMAGES_PATH,klasor+".png")
        # url=xbmc.translatePath(os.path.join(xtttest, klasor))
        # xttplay("XTTkoditools", name,"listing(IMAGES_PATH,url)", url,thumbnail,"","")
        # xttplay("", klasor,"", url,thumbnail,"","")
        
    # xttplay("xttbelgesel", "[B][COLOR lightblue]BELGESEL[/COLOR][/B]", "main()", "","", "belgesel","")
    # xttplay("xttdisney", "[COLOR yellow][B]DISNEY[/B][/COLOR]", "main()", "","", "xttdisney","")
    # xttplay("xttvizyontrial", "[B][COLOR lightblue]VIZYON[/COLOR][COLOR fuchsia]TRIAL[/COLOR][/B]", "main()", "","", "xtcinesmart","")
    # xttplay("xttmuzik", "[B][COLOR lightblue]MUZIK[/COLOR][COLOR red]BOX[COLOR dimgray][/COLOR][/B]", "main()", "","", "muzik","")
    # xttplay("xttcanliradyolive", "[B][COLOR lightblue]RADYO[/COLOR][COLOR red]BOX[COLOR dimgray][/COLOR][/B]", "main()", "","", "xttmcradyo","")
    # xttplay("XTTfullSearch", "[B][COLOR red]>>[/COLOR][COLOR yellow]ARAMA YAP[/COLOR][/B]", "main()", "","", "search","")
    # xttplay("xttmcinfo", "[B][COLOR lightblue]IN[/COLOR][COLOR red]FO[COLOR dimgray][/COLOR][/B]", "main()", "","", "xttmcinfo","")
    # xttplay("stream", "[B][COLOR lightblue]STREAM[/COLOR][COLOR red]X[/COLOR][/B]", "main()", "","", "anasayfa","")
    # xbmc.executebuiltin("Container.SetViewMode(500)")
    # xbmcplugin.setContent(int(sys.argv[1]), 'files')
    # xbmcplugin.setContent(int(sys.argv[1]), 'songs') 
    # xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    # xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
    # xbmcplugin.setContent(int(sys.argv[1]), 'seasons')
    # xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    # xbmcplugin.setContent(int(sys.argv[1]), 'albums') 
    # xbmcplugin.setContent(int(sys.argv[1]), 'artists')
    # xbmcplugin.setContent(int(sys.argv[1]), 'musicvideos')
    
    # xbmcplugin.setContent(int(sys.argv[1]), 'links')
    # xbmcplugin.setContent(int(sys.argv[1]), 'channels') 
    
# import xbmcplugin,sys
    # xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    # xbmc.executebuiltin("Container.SetViewMode(%s)" % Addon.getSetting('MAIN') )
    # xbmc.executebuiltin("Container.SetViewMode(515)")
    # xbmc.executebuiltin("Container.SetViewMode(500)")
    # xbmc.executebuiltin("Container.SetViewMode(501)")
    # xbmc.executebuiltin("Container.SetViewMode(503)")
    # xbmc.executebuiltin("Container.SetViewMode(504)")
    # xbmc.executebuiltin("Container.SetViewMode(508)")
    # xbmc.executebuiltin("Container.SetViewMode(51)")

    # xbmc.executebuiltin("Container.SetViewMode(400)")
    # xbmc.executebuiltin("Container.SetViewMode(512)")
    
    # xbmc.executebuiltin("Container.SetViewMode(50)")
    # xbmc.executebuiltin("Container.SetViewMode(52)")
    # xbmc.executebuiltin("Container.SetViewMode(53)")
    # xbmc.executebuiltin("Container.SetViewMode(54)")
    # xbmc.executebuiltin("Container.SetViewMode(55)")
    # xbmc.executebuiltin("Container.SetViewMode(60)")
    
    # xbmcplugin.endOfDirectory(int(sys.argv[1]))
######################################
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param
params = get_params()
name = None
fileName = None
method = None
url = None
thumbnail = None
thumbfolder = None
fix = None
try:
    name = urllib.unquote_plus(params["name"])
except: pass
try:
    fileName = urllib.unquote_plus(params["fileName"])
except: pass
try:
    method = urllib.unquote_plus(params["method"])
except: pass
try:
    url = urllib.unquote_plus(params["url"])
except: pass
try:
    thumbnail = urllib.unquote_plus(params["thumbnail"])
except: pass
try:
    thumbfolder = urllib.unquote_plus(params["thumbfolder"])
except: pass
try:
    fix = urllib.unquote_plus(params["fix"])
except: pass
if fileName == None:
    main()
    # listing(IMAGES_PATH,xtttest)
else:
    exec "import "+fileName+" as channel"
    exec "channel."+str(method)
xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)