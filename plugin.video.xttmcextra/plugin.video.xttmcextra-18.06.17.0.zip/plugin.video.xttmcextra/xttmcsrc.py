# -*- coding: utf-8 -*-

xttmcsrc_id = 'plugin.video.xttmcextra'
