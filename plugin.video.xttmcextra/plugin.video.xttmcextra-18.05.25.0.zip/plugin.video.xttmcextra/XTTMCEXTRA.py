# -*- coding: utf-8 -*-
import re,os,base64,xbmcgui,HTMLParser
import xbmc,cookielib
import xbmcaddon,xttmcsrc
import xbmcplugin,sys
from BeautifulSoup import BeautifulSoup
# from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS
import XTTkoditools
Addon = xbmcaddon.Addon(xttmcsrc.xttmcsrc_id)
__settings__ = xbmcaddon.Addon(id=xttmcsrc.xttmcsrc_id)
addon_icon    = __settings__.getAddonInfo('icon')
FILENAME = "XTTMCEXTRA"
# https://github.com/skymctv/skymcxml/blob/master/bein.xml
loginstream = __settings__.getSetting("loginstream")
# print loginstream
passwordstream = __settings__.getSetting("passwordstream")
# print passwordstream
web_url='https://raw.githubusercontent.com/skymctv/skymcxml/master/bein.xml'
web_xml='E:/xttmc/xttmc/skymctv/skymcxml/bein.xml'
# l_check=xttxbmctools.insidesine()
# if l_check:
        # mode=None
# else:
        # xttxbmctools.hatasine()
        # sys.revilation()
xbmcPlayer = xbmc.Player()
xbmcPlayer.stop()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
playList.clear()
def main():
        # BuildPagehtml()
        BuildPagexml()
'''################################'''
def BuildPagehtml():
#################################  orj  #########################################
    html=XTTkoditools.get_url(web_url)
    soup = BeautifulSoup(html)
def BuildPagexml():
#################################  xml  #########################################
    # if passwordstream == "":
        # print 'selam1'
        # __settings__.openSettings()
        # k = xbmc.Keyboard('', 'PIN i giriniz') ; k.doModal()
        # pin = k.getText() if k.isConfirmed() else None
        # if pin != passwordstream:
            # return
    # else:
        # print 'selam2'
        
        
    # if passwordstream == "":
        # __settings__.openSettings()
        # print '1'
        # return BuildPagexml()
        # if passwordstream == "":
            # return playList.clear(exit())
    # else:
        # print '2'
        # print "Succesfully Loged in."
        # return True
        # return xbmc.executebuiltin('Notification("[COLOR red][B]XTTMC GIRIS[/B][/COLOR]","[COLOR yellow][B]XTTMC ACILAMADI UYE DEGILMISINIZ?[/B][/COLOR]")')
    login()
    # loginstream = __settings__.getSetting("loginstream")
    # passwordstream = __settings__.getSetting("passwordstream")
    gf = open(web_xml, 'r')
    html = gf.read()
    soup = BeautifulSoup(html)
    user = HTMLParser.HTMLParser().unescape(base64.b64decode(soup.findAll('stream')[0].user.string))
    password = HTMLParser.HTMLParser().unescape(base64.b64decode(soup.findAll('stream')[0].password.string))
    m3u = HTMLParser.HTMLParser().unescape(base64.b64decode(soup.findAll('stream')[0].m3u.string))
    streamlink=user+loginstream+password+passwordstream+m3u
    link=XTTkoditools.get_url(streamlink)
    # print link
    # if panela==[]:
        # showMessage("[B][COLOR dimgray]yada Hazir Degil[/COLOR][/B]","[COLOR gray][B]XTT Player Aktif[/B][/COLOR]")
        # return playList.clear(exit())
    # else: panela=panela
    # if link == None:
        # showMessage("[B][COLOR dimgray]yada Hazir Degil[/COLOR][/B]","[COLOR gray][B]XTT Player Aktif[/B][/COLOR]")
    # else:
    match=re.compile("#EXTINF:-1,(.*?)\r\nhttp://(.*?)\r").findall(link)
    for name,url in match:
        XTTkoditools.xttplay(FILENAME,'[B][COLOR darkgray]'+name+'[/COLOR][/B]', "",'http://'+url,"",'xttsmart',"")
    xbmcplugin.setContent(int(sys.argv[1]), 'files')
    xbmc.executebuiltin("Container.SetViewMode(400)")
        
def login():
    if passwordstream == "":
        __settings__.openSettings()
        # print '1'
        # return BuildPagexml()
        if passwordstream == "":
            return playList.clear(exit())
    else:
        return
######################################
# def hataxttmc():
    # d = xbmcgui.Dialog()
    # d.ok('[COLOR red][B]XTTMC GIRIS HATASI..![/B][/COLOR]', '  [COLOR yellow][B]XTTMC[/B][/COLOR]','  [COLOR yellow][B]kayit olabilir ve bolumleri izleyebilirsiniz.[/B][/COLOR]')
    # __settings__.openSettings()
    # return xbmc.executebuiltin('Notification("[COLOR yellow][B]XTTMC GIRIS[/B][/COLOR]","[COLOR yellow][B]GIRISI TEKRARLAYIN..![/B][/COLOR]")')
# def insidexttmc():
    # login= __settings__.getSetting("loginxttmc")
    # password= __settings__.getSetting("passwordxttmc")
    # br = mechanize.Browser()
    # br.open(htmlp.unescape(base64.b64decode(xttmc)))
    # for f in br.forms():
        # br.select_form(nr=0)
    # br["usr_email"] =  str(login)
    # br["pwd"] = str(password)
    # response = br.submit()
    # key = 'xtt'+login+'xtt'
    # link = response.read()
    # if key in link:
        # return True
    # else:
        # return xbmc.executebuiltin('Notification("[COLOR red][B]XTTMC GIRIS[/B][/COLOR]","[COLOR yellow][B]XTTMC ACILAMADI UYE DEGILMISINIZ?[/B][/COLOR]")')
# def hata():
    # d = xbmcgui.Dialog()
    # d.ok('[COLOR red][B]HATA OLUSTU[/B][/COLOR]', '  [COLOR yellow][B]XTTMC[/B][/COLOR]','  [COLOR yellow][B]Farkli bir deneme yapin.[/B][/COLOR]')
    # __settings__.openSettings()
    # return xbmc.executebuiltin('Notification("[COLOR yellow][B]HATA OLUSTU[/B][/COLOR]","[COLOR yellow][B]Farkli bir deneme yapin[/B][/COLOR]")')
    
# def showMessage(str, header='', time=2000):
    # try: xbmcgui.Dialog().notification(header, str, addon_icon, time, sound=False)
    # except: xbmc.executebuiltin("Notification(%s,%s, %s, %s)" % (header, str, time, addon_icon))

def showMessage(str, header='', time=2000):
    try: xbmcgui.Dialog().notification(header, str, addon_icon, time, sound=False)
    except: xbmc.executebuiltin("Notification(%s,%s, %s, %s)" % (header, str, time, addon_icon))
def replace_fix(x):
    x=x.replace('+', ' ').replace('=', '-')
    return x
    
    
# l_check=skyxbmctools.inside24()
# if l_check:
        # mode=None
# else:
        # skyxbmctools.hata24()
        # sys.revilation()
# def INFO(url):
  # try:
        # dialog = xbmcgui.Dialog()
        # i = dialog.ok(url, "skymc24xbmc")
  # except:
        # pass 
        
# def inside24():
    # cj = cookielib.CookieJar()
    # opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    # urllib2.install_opener(opener)

    # login= __settings__.getSetting("login")
    # if not login:
        # __settings__.openSettings()
    # else:
        # pass
    # login= __settings__.getSetting("login24")
    # password= __settings__.getSetting("password24")
    # key = '24'+login+'-'+password+'p'
    # resp = opener.open(base64.b64decode(skymc))
    # data=resp.read()
    # if key in data:
        # print "Succesfully Loged in."
        # return True
    # else:
        # return xbmc.executebuiltin('Notification("[COLOR red][B]SKY  [COLOR yellow]>>[/COLOR]+24[COLOR yellow]<<[/COLOR]  GIRIS[/B][/COLOR]","[COLOR yellow][B]SKY [COLOR red] +24 [/COLOR] ACILAMADI UYE DEGILMISINIZ?[/B][/COLOR]")')

# l_check=inside24()
# if l_check:
    # mode=None
# else:
    # hata24()
    # sys.revilation()
# def INFO(url):
  # try:
        # dialog = xbmcgui.Dialog()
        # i = dialog.ok(url, "skymc24xbmc")
  # except:
        # pass 
        
        