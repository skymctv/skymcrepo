# -*- coding: utf-8 -*-
import re,os,base64,xbmcgui,HTMLParser
htmlp = HTMLParser.HTMLParser()
xttbase=base64.b64decode
import xbmc,urllib,urllib2
import xbmcaddon,xttmcsrc
import xbmcplugin,sys
import XTTkoditools
from BeautifulSoup import BeautifulSoup
# from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS
Addon = xbmcaddon.Addon(xttmcsrc.xttmcsrc_id)
__settings__ = xbmcaddon.Addon(id=xttmcsrc.xttmcsrc_id)
addon_icon    = __settings__.getAddonInfo('icon')
FILENAME = "XTTMCEXTRA"
loginstream = __settings__.getSetting("loginstream")
passwordstream = __settings__.getSetting("passwordstream")
# https://github.com/skymctv/skymcxml/blob/master/bein.xml
web_url='https://raw.githubusercontent.com/skymctv/skymcxml/master/bein.xml'
web_xml='E:/xttmc/xttmc/skymctv/skymcxml/bein.xml'
xbmcPlayer = xbmc.Player()
xbmcPlayer.stop()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
playList.clear()
def main():
    BuildPagehtml()
    # BuildPagexml()
'''################################'''

#################################  orj  #########################################
def BuildPagehtml():
    login()
    html=XTTkoditools.get_url(web_url)
    if '.' in html:
        soup = BeautifulSoup(html)
    else:
        soup = BeautifulSoup(htmlp.unescape(xttbase(html)))
    user = soup.findAll('stream')[0].user.string
    password = soup.findAll('stream')[0].password.string
    m3u = soup.findAll('stream')[0].m3u.string
    streamlink=user+loginstream+replace_fix(password)+passwordstream+replace_fix(m3u)
    try:
        link=XTTkoditools.get_url(streamlink)
    except:
        hataskymc()
        return playList.clear(exit())
    match=re.compile("#EXTINF:-1,(.*?)\r\nhttp://(.*?)\r").findall(link)
    for name,url in match:
        XTTkoditools.xttplay(FILENAME,'[B][COLOR darkgray]'+name+'[/COLOR][/B]', "",'http://'+url,"",'xttsmart',"")
    xbmcplugin.setContent(int(sys.argv[1]), 'files')
    xbmc.executebuiltin("Container.SetViewMode(400)")
    
#################################  xml  #########################################
def BuildPagexml():
    # login()
    gf = open(web_xml, 'r')
    html = gf.read()
    if '.' in html:
        soup = BeautifulSoup(html)
    else:
        soup = BeautifulSoup(htmlp.unescape(xttbase(html)))
    user = soup.findAll('stream')[0].user.string
    password = soup.findAll('stream')[0].password.string
    m3u = soup.findAll('stream')[0].m3u.string
    streamlink=user+loginstream+replace_fix(password)+passwordstream+replace_fix(m3u)
    try:
        link=XTTkoditools.get_url(streamlink)
    except:
        hataskymc()
        return playList.clear(exit())
    match=re.compile("#EXTINF:-1,(.*?)\r\nhttp://(.*?)\r").findall(link)
    for name,url in match:
        XTTkoditools.xttplay(FILENAME,'[B][COLOR darkgray]'+name+'[/COLOR][/B]', "",'http://'+url,"",'xttsmart',"")
    xbmcplugin.setContent(int(sys.argv[1]), 'files')
    xbmc.executebuiltin("Container.SetViewMode(400)")
    
######################################
def login():
    if passwordstream == "":
        # xbmcgui.Dialog().ok('[COLOR red][B]SKYMC BAGLANTI HATASI..![/B][/COLOR]', '  [COLOR blue][B]SKYMC[/B][/COLOR]','  [COLOR yellow][B]Bilgilerinizi dogru girdiginizden emin olun ve tekrar giris yapmayi deneyin.[/B][/COLOR]')
        __settings__.openSettings()
        if passwordstream == "":
            return playList.clear(exit())
    else:
        return
def hataskymc():
    xbmcgui.Dialog().ok('[COLOR red][B]SKYMC BAGLANTI HATASI..![/B][/COLOR]', '  [COLOR blue][B]SKYMC[/B][/COLOR]','  [COLOR yellow][B]Bilgilerinizi dogru girdiginizden emin olun ve tekrar giris yapmayi deneyin.[/B][/COLOR]')
    __settings__.openSettings()
    return showMessage("[B][COLOR dimgray]yada Hazir Degil[/COLOR][/B]","[COLOR gray][B]SKY Player Aktif[/B][/COLOR]")
    # return xbmc.executebuiltin('Notification("[COLOR yellow][B]XTTMC GIRIS[/B][/COLOR]","[COLOR yellow][B]GIRISI TEKRARLAYIN..![/B][/COLOR]")')
def showMessage(str, header='', time=2000):
    try: xbmcgui.Dialog().notification(header, str, addon_icon, time, sound=False)
    except: xbmc.executebuiltin("Notification(%s,%s, %s, %s)" % (header, str, time, addon_icon))
def replace_fix(x):
    x=x.replace(';=', '=')
    return x
    